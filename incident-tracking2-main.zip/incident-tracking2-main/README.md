# incident-tracking2
# 🚨 Incident Tracking System

## Features
✅ Add Multiple Incident Entries  
✅ Track & Filter Incidents  
✅ Search Incidents  
✅ Remove Incidents  
✅ Download JSON Report  

## How to Use
1. Fill in **Unit, Name, and Position**.
2. Click **"Add Incident Entry"**.
3. Enter required details for each incident.
4. Click **"Submit"**.
5. Click **"Download Report"**.

## Deployment
Enable **GitHub Pages** in repo settings.
